<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Freqeuntly Asked Question</h2>
        </div>

        <div class="row">
            <div class="col-md-5">
                <a href="<?php echo e(route('view.FAQ.Form')); ?>" class="btn btn-success">Add FAQ</a>
            </div>
        </div>

        <div class="row mt-3">
          <div class="col-md-12">
            <table class="table table-bordered table-striped">
                <tr>
                    <th>Question</th>
                    <th>Answer</th>
                    <th>Action</th>
                </tr>

                <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($val->question); ?></td>
                        <td><?php echo e($val->answer); ?></td>
                        <td>
                            <a href="<?php echo e(route('edit.FAQ', $val->faq_id)); ?>"
                                class="text-success fa-solid fa-pen-to-square" title="Edit"></a>
                            <a href="<?php echo e(route('delete.FAQ', $val->faq_id)); ?>"
                                class="text-danger fa-solid fa-trash" title="Delete"></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/FAQ.blade.php ENDPATH**/ ?>