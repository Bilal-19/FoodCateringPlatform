<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Menu Management</h2>
        </div>
        <div class="row">
            <div class="col-md-10">
                <form action="<?php echo e(route('MenuManagement')); ?>" method="GET">
                    <div class="input-group">
                        <input type="search" name="search" class="form-control" placeholder="Search Item by Name, Category">
                        <button class="btn btn-primary">Search</button>
                    </div>
                </form>
            </div>

            <div class="col-md-2">
                <button class="btn btn-danger">Reset</button>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-12">
                <?php if(count($menu) == 0): ?>
                    <p>No record found</p>
                <?php elseif(count($menu) == 1): ?>
                    <p><?php echo e(count($menu)); ?> record found</p>
                <?php else: ?>
                    <p><?php echo e(count($menu)); ?> records found</p>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <table class="table table-striped table-bordered table-hover">
                    <tr class="text-center">
                        <th>S.No</th>
                        <th>Preview Image</th>
                        <th>Item Name</th>
                        <th>Item Category</th>
                        <th>Item Price</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($val->menu_id); ?></td>
                            <td class="text-center">
                                <img src="<?php echo e(asset('images/' . $val->item_image)); ?>" alt="Menu Image"
                                    style="height: 80px; width: 80px; border-radius:50%; object-fit:cover">
                            </td>
                            <td><?php echo e($val->item_label); ?></td>
                            <td><?php echo e($val->item_category); ?></td>
                            <td><?php echo e($val->item_price); ?> PKR</td>
                            <td class="text-center">
                                <a href="<?php echo e(route('edit-menu', ['id' => $val->menu_id])); ?>"
                                    class="text-success fa-solid fa-pen-to-square" title="Edit">
                                </a>
                                <a href="<?php echo e(route('delete-menu', ['id' => $val->menu_id])); ?>"
                                    class="text-danger fa-solid fa-trash  mx-3" title="Delete">
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/MenuManagement.blade.php ENDPATH**/ ?>