<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row mt-2 mb-2">
            <h3 class="text-center text-uppercase">Login</h3>
        </div>

        <div class="row">
            <form action="<?php echo e(route('verifyCredentials')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="col-md-4 mx-auto mt-3">
                    <label for="email" class="form-label mb-0">Email: </label>
                    <input type="email" class="form-control" name="email">
                    <small class="text-danger">
                        <?php $__errorArgs = ['userEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e('The email field is required'); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <label for="password" class="form-label mb-0">Password: </label>
                    <input type="password" class="form-control" name="password">
                    <small class="text-danger">
                        <?php $__errorArgs = ['userPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e('The password field is required'); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <button class="btn btn-outline-dark">Login</button>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <p>Create a new account? <a href="<?php echo e(route('SignUp')); ?>"
                            class="text-decoration-none fw-bold text-dark">Sign Up</a></p>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <?php if(isset($errorMessage)): ?>
                        <p class="text-danger"><?php echo e($errorMessage); ?></p>
                    <?php endif; ?>
                </div>
            </form>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/LogIn.blade.php ENDPATH**/ ?>