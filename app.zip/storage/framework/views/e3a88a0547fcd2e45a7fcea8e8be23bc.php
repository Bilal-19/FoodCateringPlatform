<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">View Trash Records</h2>
        </div>

        <div class="row">
            <h5>Orders</h5>
            <div class="col-md-12">
                <hr class="mt-0">
                <?php if(count($orders) == 0): ?>
                    <p>No records found</p>
                <?php elseif(count($orders) > 0): ?>
                    <table class="table table-striped">
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Customer Email</th>
                            <th>Selected Event</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($val->order_id); ?></td>
                                <td><?php echo e($val->customer_name); ?></td>
                                <td><?php echo e($val->customer_email); ?></td>
                                <td><?php echo e($val->event_category); ?></td>
                                <td>
                                    <a href="<?php echo e(route('restore.order.trash', $val->order_id)); ?>"
                                        class="fa-solid fa-trash-arrow-up text-success" title="Restore"></a>
                                    <a href="<?php echo e(route('force.delete.order', $val->order_id)); ?>"
                                        class="fa-solid fa-trash text-danger" title="Permanent Delete"></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <div class="row mt-5">
            <h5>Menu</h5>
            <div class="col-md-12">
                <hr class="mt-0">
                <?php if(count($menu) == 0): ?>
                    <p>No records found</p>
                <?php elseif(count($menu) > 0): ?>
                    <table class="table table-striped">
                        <tr>
                            <th>ID</th>
                            <th>Item Name</th>
                            <th>Item Category</th>
                            <th>Item Price</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($val->menu_id); ?></td>
                                <td><?php echo e($val->item_label); ?></td>
                                <td><?php echo e($val->item_category); ?></td>
                                <td><?php echo e($val->item_price); ?></td>
                                <td>
                                    <a href="<?php echo e(route('restore.menu', $val->menu_id)); ?>"
                                        class="fa-solid fa-trash-arrow-up text-success" title="Restore"></a>
                                    <a href="<?php echo e(route('delete.menu', $val->menu_id)); ?>"
                                        class="fa-solid fa-trash text-danger" title="Permanent Delete"></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php endif; ?>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/ViewTrash.blade.php ENDPATH**/ ?>