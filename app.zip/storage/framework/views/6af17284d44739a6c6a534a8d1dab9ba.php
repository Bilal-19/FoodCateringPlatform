<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Add New Menu</h2>
        </div>

        <div class="row">
            <div class="col-md-8 mx-auto">
                <form action="<?php echo e(route('storeMenu')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-8 mx-auto mt-3">
                        <label for="image" class="form-label mb-0">Upload Item Image: </label>
                        <input type="file" class="form-control" name="itemImage">
                        <small class="text-danger">
                            <?php $__errorArgs = ['itemImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                    </div>

                    <div class="col-md-8 mx-auto mt-3">
                        <label for="menuLabel" class="form-label mb-0">Enter Item Label: </label>
                        <input type="text" class="form-control" name="itemLabel">
                        <small class="text-danger">
                            <?php $__errorArgs = ['itemImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                    </div>

                    <div class="col-md-8 mx-auto mt-3">
                        <label for="item-category" class="form-label mb-0">Select Item Category: </label>
                        <select name="itemCategory" id="item-category" class="form-select">
                            <?php
                                $itemCategories = [
                                    'Breakfast',
                                    'Lunch',
                                    'Dinner',
                                    'Wedding',
                                    'Birthday Party',
                                    'Corporate Events',
                                    'Family Get Together',
                                    'Holiday Parties',
                                ];
                            ?>
                            <?php $__currentLoopData = $itemCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <small class="text-danger">
                            <?php $__errorArgs = ['itemCategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                    </div>

                    <div class="col-md-8 mx-auto mt-3">
                        <label for="item-price" class="form-label mb-0">Enter Item Price: </label>
                        <input type="number" class="form-control" name="itemPrice" id="item-price">
                        <small class="text-danger">
                            <?php $__errorArgs = ['itemPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </small>
                    </div>

                    <div class="col-md-8 mx-auto mt-3">
                        <button class="btn btn-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/AddMenu.blade.php ENDPATH**/ ?>