<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row mt-2 mb-2">
            <h3 class="text-center text-uppercase">Signup</h3>
        </div>

        <div class="row">
            <form action="<?php echo e(route('newUserAccount')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-md-4 mx-auto">
                    <label for="name" class="form-label mb-0">Name: </label>
                    <input type="text" class="form-control" name="userName">
                    <small class="text-danger">
                        <?php $__errorArgs = ['userName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e('The name field is required'); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <label for="email" class="form-label mb-0">Email: </label>
                    <input type="email" class="form-control" name="userEmail">
                    <small class="text-danger">
                        <?php $__errorArgs = ['userEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e('The email field is required'); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <label for="password" class="form-label mb-0">Password: </label>
                    <input type="password" class="form-control" name="userPassword">
                    <small class="text-danger">
                        <?php $__errorArgs = ['userPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e('The password field is required'); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <button class="btn btn-outline-dark">Signup</button>
                </div>

                <div class="col-md-4 mx-auto mt-3">
                    <p>Already have an account?
                        <a href="<?php echo e(route('login')); ?>" class="text-decoration-none fw-bold text-dark">Log In</a>
                    </p>
                </div>

            </form>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Signup.blade.php ENDPATH**/ ?>