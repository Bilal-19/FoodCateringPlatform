<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">View Inventory</h2>
        </div>

        <div class="row">
            <?php echo e($findInventory); ?>


            <div class="col-md-6">
                <div class="card p-3">
                    <p><i class="fa-solid fa-id-badge"></i><?php echo e($findInventory->inventory_id); ?></p>
                    <p><i class="fa-solid fa-utensils"></i> <?php echo e($findInventory->item_name); ?></p>
                    <p><i class="fa-solid fa-id-badge"></i>ID:  <?php echo e($findInventory->inventory_id); ?></p>
                    <p><i class="fa-solid fa-id-badge"></i>ID:  <?php echo e($findInventory->inventory_id); ?></p>
                    <p><i class="fa-solid fa-id-badge"></i>ID:  <?php echo e($findInventory->inventory_id); ?></p>
                    <p><i class="fa-solid fa-id-badge"></i>ID:  <?php echo e($findInventory->inventory_id); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/ViewSingleInventory.blade.php ENDPATH**/ ?>