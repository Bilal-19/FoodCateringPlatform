<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Registered Users</h2>
        </div>

        <div class="row">
            <?php if(count($users) == 0): ?>
                <p>No record found</p>
            <?php elseif(count($users) == 1): ?>
                <p><?php echo e(count($users)); ?> record found</p>
            <?php else: ?>
                <p><?php echo e(count($users)); ?> records found</p>
            <?php endif; ?>
        </div>

        <div class="row">
            <table class="table table-striped table-bordered">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($val->name); ?></td>
                        <td><?php echo e($val->email); ?></td>
                        <td>
                            <a href="<?php echo e(route('reset.password', $val->id)); ?>" class="btn btn-primary btn-sm">Reset
                                Password</a>
                            <a href="<?php echo e(route('delete.account', $val->id)); ?>" class="btn btn-danger btn-sm">Delete Account</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/RegisteredUser.blade.php ENDPATH**/ ?>