<?php $__env->startSection('main-section'); ?>
    <?php $__env->startPush('style'); ?>
        <style>
            .card {
                height: 330px;
                width: 300px;
                margin: 10px;
            }

            .card-img {
                height: 240px;
                width: 298px;
                object-fit: cover;
            }
        </style>
    <?php $__env->stopPush(); ?>
    
    <div class="container-fluid">
        <div class="row mt-5 mb-2">
            <h3 class="text-center text-uppercase">Browse Menu</h3>
        </div>

        <div class="row">
            <form action="<?php echo e(route('menuData')); ?>" method="get">
                <div class="input-group">
                    <select name="selectCategory" class="form-select">
                        <?php
                            $itemCategories = [
                                'All Menu Items',
                                'Breakfast',
                                'Lunch',
                                'Dinner',
                                'Wedding',
                                'Birthday Party',
                                'Corporate Events',
                                'Family Get Together',
                                'Holiday Parties',
                            ];
                        ?>
                        <?php
                            $category = $search ?? '';
                        ?>
                        <?php $__currentLoopData = $itemCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>" <?php echo e($val == $category ? 'selected' : ''); ?>>
                                <?php echo e($val); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="btn btn-success">Search</button>
                </div>
            </form>
        </div>

        <div class="row">
            <p>
                <?php echo e(count($menu)); ?> records found
            </p>
        </div>

        <div class="row">
            <div class="col-md-12 d-flex flex-wrap justify-content-start">
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow mx-2">
                        <img src="<?php echo e(asset('images/' . $val->item_image)); ?>" alt="" class="card-img-top card-img">
                        <div class="card-body">
                            <h4 class="card-label"><?php echo e($val->item_label); ?></h4>
                            <p class="card-text mb-0">Price: <?php echo e($val->item_price); ?> PKR</p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/menu.blade.php ENDPATH**/ ?>