<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Add Freqeuntly Asked Question</h2>
        </div>

        <div class="row">
            <form action="<?php echo e(route('create.FAQ')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-md-4 mx-auto">
                    <label for="ques" class="form-label mb-0">Question: </label>
                    <input type="text" class="form-control" name="question">
                    <small class="text-danger">
                        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-2">
                    <label for="ques" class="form-label mb-0">Answer: </label>
                    <textarea name="answer" cols="30" rows="5" class="form-control" style="resize: none"></textarea>
                    <small class="text-danger">
                        <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mx-auto mt-2">
                    <button class="btn btn-success">Submit</button>
                </div>

                <div class="col-md-4 mx-auto mt-2">
                    <?php if(isset($message)): ?>
                        <p><?php echo e($message); ?></p>
                    <?php endif; ?>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/AddFAQ.blade.php ENDPATH**/ ?>