<?php $__env->startSection('main-section'); ?>
    <?php $__env->startPush('style'); ?>
        <style>
            i {
                height: 20px;
                width: 20px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    
    <div class="container-fluid">
        <div class="row mt-2 mb-2">
            <h3 class="text-center text-uppercase">Order History</h3>
        </div>

        <div class="row">
            <?php if(count($orderData) == 0): ?>
                <div class="col-md-12">
                    <h4 class="text-center">You haven't place any order yet.</h4>
                </div>
            <?php elseif(count($orderData) > 0): ?>
                <div class="col-md-12">
                    <table class="table table-bordered table-striped table-hover">
                        <tr>
                            <th>Selected Event Category</th>
                            <th>Order Received Date</th>
                            <th>Total No of Guest</th>
                            <th>Order Date</th>
                            <th>Order Status</th>
                        </tr>

                        <?php $__currentLoopData = $orderData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($value->event_category); ?></td>
                                <td><?php echo e($value->order_received_date); ?></td>
                                <td><?php echo e($value->total_guest); ?></td>
                                <td><?php echo e(date_format($value->created_at, 'd-m-Y')); ?></td>
                                <td><?php echo e($value->order_status == 'Packing' ? 'Delivered' : $value->order_status); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>

                
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/orderHistory.blade.php ENDPATH**/ ?>