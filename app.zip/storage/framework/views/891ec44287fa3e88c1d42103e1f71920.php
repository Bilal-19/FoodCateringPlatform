<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Inventory Management</h2>
        </div>

        <div class="row">
            <div class="col-md-4">
                <a href="<?php echo e(route('add.inventory')); ?>" class="btn btn-success">Add New Inventory</a>
            </div>
        </div>

        <div class="row  mt-2">
            <div class="col-md-12">
                <form action="<?php echo e(route('view.inventory')); ?>" method="get">
                    <div class="input-group">
                        <input type="search" name="search" class="form-control"
                            placeholder="search by item name, quantity, supplier name">
                        <button class="btn btn-primary">Search</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="row  mt-2">
            <div class="col-md-12">
                <?php if(count($inventory) > 0): ?>
                    <p><?php echo e(count($inventory)); ?> records found</p>
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Item Name</th>
                            <th>Item Quantity</th>
                            <th>Item Purchase Date</th>
                            <th>Item Cost</th>
                            <th>Supplier Name</th>
                            <th>Supplier Contact No</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($value->item_name); ?></td>
                                <td><?php echo e($value->item_quantity); ?> <?php echo e($value->item_quantity_unit); ?></td>
                                <td><?php echo e(date_format(date_create($value->item_purchase_date), 'd-M-Y')); ?></td>
                                <td><?php echo e($value->item_cost); ?></td>
                                <td><?php echo e($value->supplier_name); ?></td>
                                <td><?php echo e($value->supplier_contactno); ?></td>
                                <td>
                                    <a href="<?php echo e(route('update.inventory', $value->inventory_id)); ?>"
                                        class="text-success fa-solid fa-pen-to-square" title="Edit"></a>
                                    <a href="<?php echo e(route('delete.inventory', $value->inventory_id)); ?>"
                                        class="text-danger fa-solid fa-trash" title="Delete"></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php elseif(count($inventory) == 0): ?>
                    <p>No records found</p>
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Item Name</th>
                            <th>Item Quantity</th>
                            <th>Item Purchase Date</th>
                            <th>Item Cost</th>
                            <th>Supplier Name</th>
                            <th>Supplier Contact No</th>
                            <th>Action</th>
                        </tr>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/InventoryManagement.blade.php ENDPATH**/ ?>