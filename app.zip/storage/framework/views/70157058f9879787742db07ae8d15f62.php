<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Order Management</h2>
        </div>

        <div class="row">
            <form action="<?php echo e(route('manage_order')); ?>" method="GET">
                <div class="input-group">
                    <input type="search" name="search" class="form-control" autocomplete="off"
                        placeholder="Search by customer name, order status">
                    <button class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>

        <div class="row mt-3">
            <?php if(count($orders) == 1): ?>
                <p><?php echo e(count($orders)); ?> record found</p>
            <?php elseif(count($orders) > 1): ?>
                <p><?php echo e(count($orders)); ?> records found</p>
            <?php elseif(count($orders) == 0): ?>
                <p>No record found</p>
            <?php endif; ?>
            <div class="col-md-12">
                <table class="table table-striped table-bordered">
                    <tr>
                        <th>Customer Name</th>
                        <th>Selected Event</th>
                        <th>Order Status</th>
                        <th>Update Order Status</th>
                        <th>Action</th>
                    </tr>

                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->customer_name); ?></td>
                            <td><?php echo e($value->event_category); ?></td>
                            <td><?php echo e($value->order_status == 'Packing' ? 'Delivered' : $value->order_status); ?></td>

                            <td class="text-center">
                                <a href="<?php echo e(route('update.order', ['id' => $value->order_id])); ?>"
                                    class="btn btn-sm <?php echo e($value->order_status == 'Packing' ? 'disabled' : 'btn-primary'); ?>">
                                    Update
                                </a>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route("delete.order", $value->order_id)); ?>" class="text-danger fa-solid fa-trash" title="Delete"></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/OrderManagement.blade.php ENDPATH**/ ?>