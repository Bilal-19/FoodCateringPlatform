<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row">
            <h2 class="text-center">Add Inventory</h2>
        </div>

        <form action="<?php echo e(route('create.inventory')); ?>" class="form bg-light p-4 rounded" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row mt-4">
                <h4 class="text-uppercase">Inventory Item Information:</h4>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label for="itemName" class="form-label mb-0">Enter Item Name: </label>
                    <input type="text" class="form-control" name="item_name">
                    <small class="text-danger">
                        <?php $__errorArgs = ['item_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4">
                    <label for="itemCategory" class="form-label mb-0">Select Item Category: </label>
                    <?php
                        $itemCategories = [
                            'Vegetables',
                            'Meats',
                            'Diary',
                            'Grains',
                            'Seafood',
                            'Nuts and Seeds',
                            'Fats and Oils',
                            'Sweets and Sugars',
                            'Beverages',
                        ];
                    ?>
                    <select name="item_category" class="form-select">
                        <?php $__currentLoopData = $itemCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="text-danger">
                        <?php $__errorArgs = ['item_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4">
                    <label for="itemVariant" class="form-label mb-0">Select Item Variant: </label>
                    <?php
                        $itemVariant = [
                            'Organic',
                            'Frozen',
                            'Fresh',
                            'Canned',
                            'Processed',
                            'Low-Fat',
                            'Dehydrated',
                            'Sweets and Sugars',
                            'Pre-Cooked',
                        ];
                    ?>
                    <select name="item_variant" class="form-select">
                        <?php $__currentLoopData = $itemVariant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="text-danger">
                        <?php $__errorArgs = ['item_variant'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mt-3">
                    <label for="itemQuantity" class="form-label mb-0">Select Item Quantity: </label>
                    <div class="input-group">
                        <select name="item_quantity" class="form-select">
                            <?php for($i = 1; $i <= 10; $i++): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                        <?php
                            $itemQuantityUnit = [
                                'g (Grams)',
                                'kg (Kilograms)',
                                'mg (Milligrams)',
                                'lb (Pounds)',
                                'oz (Ounces)',
                                'ml (Milliliters)',
                                'L (Liters)',
                                'dozen',
                            ];
                        ?>
                        <select name="item_quantity_unit" id="" class="form-select">
                            <?php $__currentLoopData = $itemQuantityUnit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val); ?>"><?php echo e($val); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-4 mt-3">
                    <label for="purchaseDate" class="form-label mb-0">Select Purchase Date: </label>
                    <input type="date" class="form-control" name="purchase_date">
                    <small class="text-danger">
                        <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4 mt-3">
                    <label for="itemCost" class="form-label mb-0">Enter Item Cost: </label>
                    <input type="number" class="form-control" name="item_cost">
                    <small class="text-danger">
                        <?php $__errorArgs = ['item_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
            </div>

            <div class="row mt-4">
                <h4 class="text-uppercase">Supplier Information:</h4>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label for="supplierName" class="form-label mb-0">Enter Supplier Name: </label>
                    <input type="text" class="form-control" name="supplier_name">
                    <small class="text-danger">
                        <?php $__errorArgs = ['supplier_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>

                <div class="col-md-4">
                    <label for="supplierContactNo" class="form-label mb-0">Enter Supplier Contact No: </label>
                    <input type="number" class="form-control" name="supplier_contactno">
                    <small class="text-danger">
                        <?php $__errorArgs = ['supplier_contactno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 mt-3">
                    <button class="btn btn-success">Submit</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminDashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/Admin/AddInventory.blade.php ENDPATH**/ ?>