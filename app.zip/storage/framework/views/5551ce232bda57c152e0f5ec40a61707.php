<?php $__env->startPush('style'); ?>
    <style>
        body {
            background-image: url('https://images.unsplash.com/photo-1544027993-37dbfe43562a?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D');
            background-repeat: no-repeat;
        }

        .fa-icon {
            height: 20px;
            width: 18px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
    <div class="container-fluid">
        <div class="row mt-2">
            <div class="col-md-4 mx-auto text-center">
                <h3 class="text-uppercase p-2">Customer Support</h3>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-2"></div>
            <div class="col-md-3">
                <div class="card bg-light text-dark p-3">
                    <h5 class="p-2 text-center">Contact Information</h5>
                    <p class="mb-0 card-text"><i class="fa-icon fa-solid fa-phone"></i> 03082491543</p>
                    <p class="mb-0 card-text"><i class="fa-icon fa-solid fa-envelope"></i> info@catering.com</p>
                    <p class="mb-0 card-text"><i class="fa-icon fa-solid fa-location-dot"></i> Karachi, Pakistan</p>
                    <p class="mb-2 card-text"><i class="fa-icon fa-solid fa-clock"></i> 9am - 6pm</p>
                </div>
            </div>

            <div class="col-md-1"></div>

            <div class="col-md-5">
                <div class="card bg-light text-dark pt-2 pb-3">
                    <h5 class="text-center">Contact Us</h5>
                    <form action="<?php echo e(route('customerInquiry')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-8 mx-auto">
                            <label for="user_name" class="form-label mb-0">Name: </label>
                            <input type="text" class="form-control" name="user_name">
                            <small class="text-danger">
                                <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </small>
                        </div>

                        <div class="col-md-8 mx-auto">
                            <label for="useremail" class="form-label mb-0 mt-2">Email: </label>
                            <input type="email" class="form-control" name="user_email">
                            <small class="text-danger">
                                <?php $__errorArgs = ['user_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </small>
                        </div>

                        <div class="col-md-8 mx-auto">
                            <label for="usermessage" class="form-label mb-0 mt-2">Message: </label>
                            <textarea name="user_message" cols="30" rows="5" class="form-control" style="resize: none;"></textarea>
                            <small class="text-danger">
                                <?php $__errorArgs = ['user_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </small>
                        </div>

                        <div class="col-md-8 mx-auto">
                            <button class="btn btn-outline-dark mt-3">Submit</button>
                        </div>

                        <?php if(isset($message)): ?>
                            <p class="<?php echo e($style); ?> text-center"><?php echo e($message); ?></p>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\FullStack\Projects\FoodCateringPlatform\resources\views/customerSupport.blade.php ENDPATH**/ ?>