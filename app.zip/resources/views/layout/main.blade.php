@include('layout.header')
<div class="container-fluid">
    @yield('main-section')
</div>
@include('layout.footer')
